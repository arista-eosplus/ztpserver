==========
ClientXMPP
==========

.. module:: sleekxmpp.clientxmpp

.. autoclass:: ClientXMPP
    :members:
