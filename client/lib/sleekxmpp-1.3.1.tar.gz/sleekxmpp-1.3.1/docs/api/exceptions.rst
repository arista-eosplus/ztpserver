Exceptions
==========

.. module:: sleekxmpp.exceptions

    
.. autoexception:: XMPPError
    :members:

.. autoexception:: IqError
    :members:

.. autoexception:: IqTimeout
    :members:
