.. module:: sleekxmpp.xmlstream.filesocket

.. _filesocket:

Python 2.6 File Socket Shims
============================

.. autoclass:: FileSocket
    :members:

.. autoclass:: Socket26
    :members:
